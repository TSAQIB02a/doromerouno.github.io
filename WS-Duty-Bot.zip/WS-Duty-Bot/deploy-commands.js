require("dotenv").config();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("lapor-duty")
    .setDescription("Kirim laporan duty Workshop")
    .addStringOption(o => o.setName("tanggal").setDescription("Tanggal duty, format YYYY-MM-DD").setRequired(true))
    .addIntegerOption(o => o.setName("durasi").setDescription("Durasi duty dalam menit").setRequired(true).setMinValue(1).setMaxValue(1440))
    .addIntegerOption(o => o.setName("pelayanan").setDescription("Jumlah kendaraan/pelayanan (0 jika tidak dihitung)").setRequired(true).setMinValue(0).setMaxValue(10000))
    .addAttachmentOption(o => o.setName("bukti").setDescription("Screenshot bukti duty").setRequired(true)),
  new SlashCommandBuilder()
    .setName("cek-duty")
    .setDescription("Lihat total duty dan status laporanmu")
    .addUserOption(o => o.setName("mekanik").setDescription("Opsional: lihat mekanik lain (khusus admin)").setRequired(false)),
  new SlashCommandBuilder()
    .setName("rekap-duty")
    .setDescription("Lihat rekap duty mekanik (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(o => o.setName("mekanik").setDescription("Opsional: rekap satu mekanik").setRequired(false)),
  new SlashCommandBuilder()
    .setName("atur-duty")
    .setDescription("Atur durasi minimum laporan duty (admin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addIntegerOption(o => o.setName("menit").setDescription("Durasi minimum dalam menit").setRequired(true).setMinValue(1).setMaxValue(1440))
].map(c => c.toJSON());

async function main() {
  const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
  if (!DISCORD_TOKEN || !CLIENT_ID || !GUILD_ID) {
    throw new Error("Isi DISCORD_TOKEN, CLIENT_ID, dan GUILD_ID di file .env terlebih dahulu.");
  }
  const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
  console.log("Slash command berhasil didaftarkan ke server:", GUILD_ID);
}
main().catch(err => { console.error(err); process.exit(1); });
