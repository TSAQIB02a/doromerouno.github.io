# Bot Verifikasi Duty WS SA-MP

Bot sederhana untuk Discord menggunakan Node.js, discord.js v14, dan SQLite.

## Fitur
- `/lapor-duty`: tanggal, durasi menit, jumlah pelayanan, screenshot wajib.
- Validasi format tanggal dan tipe lampiran gambar.
- Durasi minimum bisa diatur admin lewat `/atur-duty`.
- Laporan yang lolos pemeriksaan teknis berstatus `VALID` dan durasinya masuk rekap.
- Laporan yang kurang dari durasi minimum berstatus `REVISI`.
- Deteksi screenshot identik dengan hash SHA-256.
- `/cek-duty`: melihat total durasi valid dan lima laporan terbaru.
- `/rekap-duty`: rekap semua mekanik atau satu mekanik (admin).
- Data tersimpan di `data/ws-duty.sqlite`.

## Persyaratan
- Node.js 20.11 atau lebih baru (disarankan Node.js LTS terbaru).
- Akun Discord dan akses membuat aplikasi/bot di Discord Developer Portal.
- Izin bot di server: View Channels, Send Messages, Embed Links, Use Application Commands.
- Admin yang mengatur minimum duty perlu izin `Manage Server`.

## 1. Buat bot Discord
1. Buka https://discord.com/developers/applications
2. Klik **New Application** dan beri nama bot.
3. Buka menu **Bot**, buat/reset token lalu salin token. Jangan bagikan token kepada siapa pun.
4. Buka **OAuth2 > URL Generator**.
5. Pilih scope `bot` dan `applications.commands`.
6. Pilih izin: `View Channels`, `Send Messages`, `Embed Links`, `Attach Files` (opsional untuk pengembangan berikutnya).
7. Buka URL undangan yang dibuat lalu tambahkan bot ke server WS.
8. Di **General Information**, salin **Application ID**.
9. Aktifkan Developer Mode Discord, klik kanan server > **Copy Server ID**.

## 2. Siapkan folder
1. Ekstrak ZIP ini ke folder, misalnya `C:\\WS-Duty-Bot`.
2. Salin `.env.example`, lalu ubah nama salinannya menjadi `.env`.
3. Buka `.env` dengan Notepad dan isi:
   - `DISCORD_TOKEN` = token bot
   - `CLIENT_ID` = Application ID
   - `GUILD_ID` = ID server Discord
   - `MIN_DUTY_MINUTES` = durasi minimum awal (menit)
4. Simpan. Jangan kirim file `.env` ke orang lain.

## 3. Jalankan melalui Windows CMD
Masuk ke folder bot. Contoh:
```bat
cd /d C:\\WS-Duty-Bot
npm install
npm run deploy
npm start
```
Biarkan CMD tetap terbuka agar bot online. `npm run deploy` cukup dijalankan lagi jika daftar slash command berubah.

Jika muncul masalah saat memasang `better-sqlite3`, pastikan Node.js versi LTS terbaru terpasang, lalu tutup dan buka kembali CMD dan jalankan `npm install` lagi.

## 4. Cara pakai
- `/atur-duty menit:60` — admin menetapkan minimum 60 menit. Sesuaikan dengan aturan WS yang sebenarnya.
- `/lapor-duty tanggal:2026-10-12 durasi:75 pelayanan:8 bukti:[unggah screenshot]`
- `/cek-duty`
- `/rekap-duty`
- `/rekap-duty mekanik:@NamaMekanik`

## Penting tentang validasi
`VALID` berarti lolos pemeriksaan teknis: kolom terisi, tanggal valid, durasi mencapai minimum, lampiran berupa gambar, dan screenshot tidak identik dengan screenshot yang sudah tersimpan pada server tersebut. Ini **tidak membuktikan** screenshot asli, bahwa mekanik benar-benar duty di dalam game, atau bahwa jumlah pelayanan benar. Verifikasi konten screenshot masih perlu proses/manual rule tambahan. Jangan gunakan status ini sebagai bukti anti-kecurangan yang sempurna.

## Database dan backup
Data SQLite berada di `data/ws-duty.sqlite`. Matikan bot sebelum menyalin file database untuk backup. Jangan menghapus folder `data` jika ingin menyimpan riwayat laporan.

## Catatan
- Bot saat ini menyimpan laporan di server tempat laporan dikirim.
- `/cek-duty` hanya menampilkan rekap untuk pengguna sendiri kecuali pemanggil admin.
- Laporan yang durasinya di bawah minimum tetap disimpan sebagai `REVISI`, tetapi tidak masuk akumulasi total duty.
- Hash screenshot hanya mendeteksi file yang identik byte-per-byte; gambar yang diedit atau diubah ukurannya bisa lolos dari deteksi.
