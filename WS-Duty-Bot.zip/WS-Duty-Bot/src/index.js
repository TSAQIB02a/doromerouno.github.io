require("dotenv").config();

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const Database = require("better-sqlite3");
const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  AttachmentBuilder,
  PermissionFlagsBits
} = require("discord.js");

const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error("DISCORD_TOKEN belum diisi. Salin .env.example menjadi .env lalu isi token.");
  process.exit(1);
}

const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "ws-duty.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    username TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    report_date TEXT NOT NULL,
    duration_minutes INTEGER NOT NULL,
    service_count INTEGER NOT NULL,
    screenshot_url TEXT NOT NULL,
    screenshot_hash TEXT NOT NULL,
    status TEXT NOT NULL,
    reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_reports_user_status ON reports(user_id, status);
  CREATE INDEX IF NOT EXISTS idx_reports_guild_date ON reports(guild_id, report_date);
`);

const getSetting = db.prepare("SELECT value FROM settings WHERE key = ?");
const setSetting = db.prepare(`
  INSERT INTO settings(key, value) VALUES(?, ?)
  ON CONFLICT(key) DO UPDATE SET value = excluded.value
`);
function getMinimum() {
  const row = getSetting.get("min_duty_minutes");
  const fromDb = row ? Number(row.value) : NaN;
  const fromEnv = Number(process.env.MIN_DUTY_MINUTES || 60);
  return Number.isInteger(fromDb) && fromDb > 0 ? fromDb :
    (Number.isInteger(fromEnv) && fromEnv > 0 ? fromEnv : 60);
}

const insertReport = db.prepare(`
  INSERT INTO reports
  (user_id, username, guild_id, channel_id, report_date, duration_minutes,
   service_count, screenshot_url, screenshot_hash, status, reason)
  VALUES (@user_id, @username, @guild_id, @channel_id, @report_date, @duration_minutes,
   @service_count, @screenshot_url, @screenshot_hash, @status, @reason)
`);
const sumDuty = db.prepare(`
  SELECT COALESCE(SUM(duration_minutes), 0) AS total, COUNT(*) AS reports
  FROM reports WHERE user_id = ? AND guild_id = ? AND status = 'VALID'
`);
const latestReports = db.prepare(`
  SELECT id, report_date, duration_minutes, service_count, status, reason, created_at
  FROM reports WHERE user_id = ? AND guild_id = ? ORDER BY id DESC LIMIT 5
`);
const allReportSums = db.prepare(`
  SELECT user_id, username, SUM(duration_minutes) AS total, COUNT(*) AS reports
  FROM reports WHERE guild_id = ? AND status = 'VALID'
  GROUP BY user_id, username ORDER BY total DESC LIMIT 15
`);
const oneReportSum = db.prepare(`
  SELECT user_id, username, SUM(duration_minutes) AS total, COUNT(*) AS reports
  FROM reports WHERE guild_id = ? AND user_id = ? AND status = 'VALID'
  GROUP BY user_id, username
`);
const duplicateHash = db.prepare(`
  SELECT id, user_id FROM reports WHERE guild_id = ? AND screenshot_hash = ? LIMIT 1
`);

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

function isAdmin(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) ?? false;
}
function validDate(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
  const d = new Date(`${date}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === date;
}
function formatDuration(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} menit`;
  if (m === 0) return `${h} jam`;
  return `${h} jam ${m} menit`;
}
function reportEmbed({ title, color, description, fields = [] }) {
  return new EmbedBuilder()
    .setTitle(title)
    .setColor(color)
    .setDescription(description)
    .addFields(fields)
    .setTimestamp();
}
async function hashAttachment(url) {
  // Unduh hanya lampiran yang dikirim untuk laporan. Batas 10 MB untuk menghindari unduhan besar.
  const response = await fetch(url);
  if (!response.ok) throw new Error("Screenshot tidak dapat diunduh untuk pemeriksaan.");
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > 10 * 1024 * 1024) throw new Error("Ukuran screenshot maksimal 10 MB.");
  return crypto.createHash("sha256").update(buffer).digest("hex");
}

client.once("ready", () => {
  console.log(`Bot aktif sebagai ${client.user.tag}`);
  console.log(`Durasi minimum laporan saat ini: ${getMinimum()} menit`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  try {
    if (interaction.commandName === "lapor-duty") {
      if (!interaction.inGuild()) {
        return interaction.reply({ content: "Perintah ini hanya bisa digunakan di server Discord.", ephemeral: true });
      }

      const date = interaction.options.getString("tanggal", true);
      const duration = interaction.options.getInteger("durasi", true);
      const serviceCount = interaction.options.getInteger("pelayanan", true);
      const attachment = interaction.options.getAttachment("bukti", true);

      if (!validDate(date)) {
        return interaction.reply({ content: "Tanggal tidak valid. Gunakan format `YYYY-MM-DD`, contoh `2026-10-12`.", ephemeral: true });
      }
      if (!attachment.contentType?.startsWith("image/")) {
        return interaction.reply({ content: "Bukti wajib berupa file gambar (PNG, JPG, WEBP, dan sejenisnya).", ephemeral: true });
      }
      if (attachment.size > 10 * 1024 * 1024) {
        return interaction.reply({ content: "Ukuran screenshot maksimal 10 MB.", ephemeral: true });
      }

      await interaction.deferReply({ ephemeral: true });

      const hash = await hashAttachment(attachment.url);
      const duplicate = duplicateHash.get(interaction.guildId, hash);
      if (duplicate) {
        return interaction.editReply(`Laporan tidak disimpan: screenshot ini sudah pernah dipakai pada laporan #${duplicate.id}. Jika ini kekeliruan, hubungi admin WS.`);
      }

      const minimum = getMinimum();
      const status = duration >= minimum ? "VALID" : "REVISI";
      const reason = status === "VALID"
        ? "Kolom wajib terisi, durasi memenuhi minimum, dan screenshot terlampir. Keaslian isi screenshot tidak dapat dipastikan otomatis."
        : `Durasi ${duration} menit kurang dari minimum WS ${minimum} menit.`;

      const result = insertReport.run({
        user_id: interaction.user.id,
        username: interaction.user.username,
        guild_id: interaction.guildId,
        channel_id: interaction.channelId,
        report_date: date,
        duration_minutes: duration,
        service_count: serviceCount,
        screenshot_url: attachment.url,
        screenshot_hash: hash,
        status,
        reason
      });

      const embed = reportEmbed({
        title: `Laporan Duty WS #${result.lastInsertRowid}`,
        color: status === "VALID" ? 0x2ecc71 : 0xf1c40f,
        description: status === "VALID"
          ? "Status: **VALID — lolos pemeriksaan teknis otomatis**"
          : "Status: **REVISI — perbaiki laporan sesuai alasan di bawah**",
        fields: [
          { name: "Mekanik", value: `<@${interaction.user.id}>`, inline: true },
          { name: "Tanggal", value: date, inline: true },
          { name: "Durasi", value: formatDuration(duration), inline: true },
          { name: "Pelayanan", value: String(serviceCount), inline: true },
          { name: "Bukti", value: `[Lihat screenshot](${attachment.url})`, inline: true },
          { name: "Alasan", value: reason }
        ]
      });

      // Posting hasil ke channel laporan yang sama. Jika izin channel tidak ada, laporan tetap tersimpan.
      try {
        await interaction.channel.send({ embeds: [embed] });
      } catch (err) {
        console.warn("Tidak bisa mengirim embed ke channel:", err.message);
      }

      return interaction.editReply(
        status === "VALID"
          ? `Laporan #${result.lastInsertRowid} lolos pemeriksaan teknis. Durasi ${formatDuration(duration)} masuk ke total duty. Catatan: bot tidak dapat memastikan keaslian isi screenshot.`
          : `Laporan #${result.lastInsertRowid} berstatus REVISI. ${reason}`
      );
    }

    if (interaction.commandName === "cek-duty") {
      if (!interaction.inGuild()) return interaction.reply({ content: "Gunakan perintah ini di server.", ephemeral: true });
      const target = interaction.options.getUser("mekanik") || interaction.user;
      if (target.id !== interaction.user.id && !isAdmin(interaction)) {
        return interaction.reply({ content: "Hanya admin yang dapat melihat rekap mekanik lain.", ephemeral: true });
      }
      const total = sumDuty.get(target.id, interaction.guildId);
      const rows = latestReports.all(target.id, interaction.guildId);
      const lines = rows.length
        ? rows.map(r => `#${r.id} · ${r.report_date} · ${formatDuration(r.duration_minutes)} · **${r.status}**${r.reason && r.status !== "VALID" ? ` — ${r.reason}` : ""}`).join("\n")
        : "Belum ada laporan.";

      const embed = reportEmbed({
        title: `Rekap Duty — ${target.username}`,
        color: 0x5865f2,
        description: `**Total duty valid:** ${formatDuration(total.total)}\n**Laporan valid:** ${total.reports}\n\n**5 laporan terbaru:**\n${lines}`
      });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (interaction.commandName === "rekap-duty") {
      if (!interaction.inGuild()) return interaction.reply({ content: "Gunakan perintah ini di server.", ephemeral: true });
      if (!isAdmin(interaction)) return interaction.reply({ content: "Perintah ini khusus admin dengan izin Manage Server.", ephemeral: true });

      const target = interaction.options.getUser("mekanik");
      if (target) {
        const row = oneReportSum.get(interaction.guildId, target.id);
        const total = row?.total || 0;
        return interaction.reply({
          embeds: [reportEmbed({
            title: `Rekap Duty — ${target.username}`,
            color: 0x5865f2,
            description: `**Total duty valid:** ${formatDuration(total)}\n**Jumlah laporan valid:** ${row?.reports || 0}`
          })],
          ephemeral: true
        });
      }

      const rows = allReportSums.all(interaction.guildId);
      const description = rows.length
        ? rows.map((r, i) => `**${i + 1}.** <@${r.user_id}> — ${formatDuration(r.total)} (${r.reports} laporan)`).join("\n")
        : "Belum ada laporan valid.";
      return interaction.reply({
        embeds: [reportEmbed({ title: "Rekap Duty WS", color: 0x5865f2, description })],
        ephemeral: true
      });
    }

    if (interaction.commandName === "atur-duty") {
      if (!interaction.inGuild()) return interaction.reply({ content: "Gunakan perintah ini di server.", ephemeral: true });
      if (!isAdmin(interaction)) return interaction.reply({ content: "Perintah ini khusus admin dengan izin Manage Server.", ephemeral: true });
      const minutes = interaction.options.getInteger("menit", true);
      setSetting.run("min_duty_minutes", String(minutes));
      return interaction.reply({ content: `Durasi minimum laporan duty WS sekarang **${minutes} menit**.`, ephemeral: true });
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat memproses perintah:", error);
    const message = "Terjadi kesalahan saat memproses laporan. Coba lagi; jika berulang, periksa terminal bot.";
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(message).catch(() => {});
    } else {
      await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
    }
  }
});

client.login(token);
